# ICLO × Snowflake Meeting Kit v10

Audience: Snowflake HLS GTM specialist, Industry Architect, Solution Engineer, security/compliance owner, and startup/partner lead.

Scope: U.S. self-funded employer dental-benefit PoC.

## Open fields — who fills each one

Three families, not two. The first is ICLO's own record and must be complete before anything is sent; the other two are the ask in this meeting.

| Field | Owner | Where it appears | Must be closed before |
|---|---|---|---|
| ICLO legal entity, headquarters, stage, core team size | ICLO | EN deck slide 16; EN report p.3; KO deck slide 16; KO report p.3 | External release |
| Official Snowflake program name and current sponsor | Snowflake | Deck slide 16; action register | Meeting + 3 business days |
| Current account, cloud, region, credits, usage, technical-support owner | Snowflake | Deck slides 13 and 16; EN report p.3 | Meeting + 10 business days |

## 90-second opening statement — external English

ICLO is building an employee dental-benefit navigation and claims-verified evidence layer. We are already receiving Snowflake startup support, and this proposal converts that relationship into a structured 90-day joint validation.

The PoC is explicitly for a U.S. self-funded employer dental benefit. In the front, employees understand coverage, find appropriate in-network care and request support. In the back, eligibility, plan context, app events and dental claims become aggregate evidence for employer decisions without exposing employee-level health signals. The employer bears dental claim risk, while a dental carrier or TPA may administer eligibility, network rules and claims.

We will not promise first-year savings: preventive use and newly discovered treatment may raise plan-paid claims before longer-term treatment-mix change is measurable. We see Snowflake as the governed evidence and collaboration plane. We are not asking Snowflake to validate our dental AI, make ICLO compliant or provide generic customer introductions. We are asking the current Korea startup sponsor to route us to the appropriate U.S. HLS owners, align the sales play, validate the architecture and test one account-team use case. The goal is to learn what ICLO must prove for a repeatable, commercially real payer/TPA collaboration pattern.

## 45-minute agenda — single source of truth

| Minutes | Topic | Decision / output |
|---:|---|---|
| 0–8 | Business fit | Primary HLS sales play and strongest Snowflake story |
| 8–16 | Account ecosystem | Account types and evidence required for a named-account map |
| 16–29 | Architecture | Share/ingestion, tenancy, PHI boundary and sizing questions |
| 29–38 | Partnership path | Startup/partner/ISV path and readiness criteria |
| 38–45 | Next actions | Named owners, dates and required written outputs |

## Action register — single source of truth

| Action | Snowflake owner | ICLO owner | Due date | Required output |
|---|---|---|---|---|
| Confirm support relationship and route to U.S. HLS | Current Korea startup sponsor | CEO / GTM lead | Meeting + 3 business days | Official program name, sponsor and U.S. HLS route |
| Confirm HLS sales play and working-session team | HLS GTM / Industry Architect | CEO / product lead | Meeting + 5 business days | Primary/secondary play plus architect, SE and security contacts |
| Confirm U.S. account, region, Business Critical and BAA path | Account / security owner | Security lead | Meeting + 10 business days | Written decision path and prerequisites |
| Confirm startup credits and technical support | Startup / Partner lead | Finance / operations | Meeting + 10 business days | Amount, term, exclusions and support scope in writing |
| Run 2.5K / 10K / 25K workload sizing | Solution Engineer | Data lead | Day 30 | Sizing inputs, pre-credit run-rate economics, and credits shown separately as a time-limited sensitivity |
| Document the dental data-rights matrix | Not a Snowflake action | Security / legal lead | Day 30 | Rights by source, field, purpose, recipient, retention and onward-sharing limit |
| Accept the security reference architecture | HLS architect / security owner | Security lead | Day 60 | Identities, data classification, encryption and keys, logging, retention, incident response, environments, named approver |
| Complete one account diligence row | HLS GTM + account owner | GTM lead | Day 30 | Entity, dental data, region, incumbent and readiness |
| Build named-account matrix v1 | HLS GTM + account teams | GTM lead | Day 45 | Account-level dental workload and validation readiness |
| Run one account-team use-case review | Named account owner | CEO / product lead | Day 75 | Written architecture and unmet-need feedback |
| Decide partner path | Startup / Partner lead | CEO / partnerships | Day 90 | Checklist and proceed/defer decision |

## 진행 메모 — 내부용

- Step 0은 고객 소개 요청이 아니라, 현재 한국 스타트업 스폰서가 미국 HLS GTM·아키텍처 담당자를 지정·연결하는 라우팅 단계입니다.
- Day 30의 “계정 검증 행 1건 작성”과 Day 75의 “계정팀 사용사례 검토”는 서로 다른 액션입니다.
- 크레딧 금액·기간·제외사항은 Startup / Partner lead가 서면으로 확인합니다. Solution Engineer의 규모 산정은 크레딧 반영 전 정상 단가를 먼저 산출하고, 크레딧은 기간 한정 민감도로 따로 표시합니다.
- ICLO가 주간 서면 현황과 단일 의사결정 기록을 운영합니다.
- 조건부 확장은 계정팀 검토에서 다자간 수요가 확인된 경우에만 검토합니다.
- 데이터 권리 매트릭스는 Snowflake 요청 항목이 아니라 ICLO·고객이 Day 30까지 완료하는 선행 조건입니다. 이것 없이는 아키텍처와 계정 검토가 모두 가정에 머무릅니다.
- Day 0은 스폰서가 라우팅을 서면으로 수락한 날입니다. “회의 + N영업일”과 “Day N”은 같은 기준일에서 셉니다.

## Explicit non-asks

- No legal or regulatory determination from Snowflake.
- No claim that Business Critical and a BAA make ICLO as a whole HIPAA-compliant.
- No validation of ICLO’s dental AI or raw-image security program.
- No generic customer introductions before account-level evidence.
- No year-one dental-claims savings guarantee.
