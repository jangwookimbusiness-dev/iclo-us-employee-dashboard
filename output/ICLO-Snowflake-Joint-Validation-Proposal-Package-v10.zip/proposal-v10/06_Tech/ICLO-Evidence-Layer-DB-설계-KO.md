# 근거 레이어 DB 설계 — 임직원 치과복지 증거 데이터

ICLO × Snowflake · 미국 self-funded employer 치아보험 PoC
2026-08-08 · 내부 기술 문서 · v1

---

## 0. 이 문서의 범위

대시보드가 보여주는 숫자를 실제로 만들어내는 **개인 레벨 데이터베이스**를 어떻게 짓는지 다룹니다. 대상은 ICLO 데이터 엔지니어와 Snowflake HLS 아키텍트입니다.

다루는 것: 원천 수집 · 신원 해석 · 정본 모델 · member-month 전개 · 청구 지연 처리 · PHI 경계 · Snowflake 물리 설계 · 거버넌스 정책 · 기업 화면용 집계.

**다루지 않는 것:** 앱 프론트엔드, 모델 학습·추론 파이프라인, 계약·법무 판단. 마지막 절에 법무 입력이 필요한 항목을 따로 모아두었습니다.

### 가정 (전부 미확정 — 확인 후 갱신 필요)

이 설계는 아래를 가정합니다. **하나라도 틀리면 해당 절을 다시 봐야 합니다.**

| # | 가정 | 틀렸을 때 영향 |
|---|---|---|
| A1 | 첫 파일럿은 계약 기업 1곳, 자격자 약 10,000명 | 규모 가정이 바뀌면 8절 웨어하우스 사이징 |
| A2 | TPA가 837D/835 또는 합의된 청구 추출을 월 1회 제공 | 실시간이면 3·6절 전면 재설계 |
| A3 | HRIS가 834 가입 자격 파일을 월 1회 SFTP 제공 | 일 단위면 5절 member-month 전개 주기 변경 |
| A4 | 원본 구강 이미지는 ICLO 운영 미국 리전 객체 저장소에 보관하고 Snowflake에 넣지 않음 | 7절 PHI 경계 전체 |
| A5 | Snowflake **Business Critical**, 미국 리전, BAA 체결 완료 | 미체결 시 PHI 적재 불가 — 착수 전제 |
| A6 | HRIS와 TPA 양쪽에 공통 식별자(subscriber ID)가 있고 생년월일·관계코드로 보강 가능 | 없으면 4절 신원 해석이 가장 큰 리스크로 승격 |
| A7 | 청구 run-out 90일, 그 이후 재작성은 드묾 | 더 길면 6절 스냅샷 정책 |
| A8 | 기업 화면 최소 셀 크기 20 | 법무 판단으로 바뀔 수 있음 (13절) |
| A9 | 임직원용 웹앱은 **아직 만들지 않았음**. 추론은 ICLO Core AI를 API로 호출 | 14절 전체. 계약·일정에 반영 필요 |

가정 A5와 A6이 가장 위험합니다. A5는 착수 자체를 막고, A6은 실패하면 청구와 앱 이용을 연결할 수 없어 "청구로 확인된 완료"라는 제품의 핵심 주장이 성립하지 않습니다.

---

## 1. 무엇을 만들어야 하는지 — 화면에서 역산

대시보드 지표를 거꾸로 따라가면 필요한 테이블이 나옵니다.

| 화면 지표 | 계산 | 필요한 것 |
|---|---|---|
| Eligible employees | 기준 시점에 플랜 자격이 있는 임직원 수 | 가입 자격 기간(span), 관계코드 |
| Covered members | 임직원 + 등록 가족의 **가입자-월** | span을 월 단위로 전개 |
| Activated 38% | 가입 + 첫 문진 완료 / 자격자 | 앱 이벤트, 동의 시각 |
| Repeat participation 61% | 재참여 / 활성 사용자 | 앱 이벤트 시계열 |
| Dental PMPM $31.40 | 허용액 합 / 가입자-월 | 청구 라인 + member-month |
| Signals Low·Moderate·Priority | 유효 촬영의 신호 분포 | 사진 파생 신호, 모델 버전 |
| Open / Completed care actions | 조치 발생·완료 | 앱 이벤트 **+ 청구 라인 연결** |
| completeness 98.4% | 도착한 청구 / 예상 청구 | 청구 수신 대조 |

**개입군/대조군 추세는 v1에 없습니다.** 대조군이 있어야 성립하는데 실험군 배정이 미해결(4.5절·13절)이라 대시보드에서 `Trend vs control` 탭을 뺐습니다. 배정 설계가 승인되면 돌아옵니다.

**"청구로 확인된 완료"가 이 시스템의 존재 이유입니다.** 앱 이벤트만으로는 자가 보고이고, 청구만으로는 ICLO의 개입 여부를 모릅니다. 둘을 **같은 사람으로 연결**해야 성립하고, 그래서 개인 레벨 저장이 불가피합니다. 집계는 저장하지 않는다는 뜻이 아니라 **기업이 볼 수 있는 것을 제한한다**는 뜻입니다.

---

## 2. 원천 시스템과 수집

| 원천 | 내용 | 형식 | 주기 | 수집 |
|---|---|---|---|---|
| 기업 HRIS | 가입 자격, 플랜 설계 | X12 **834** | 월 1회 (변경분) | SFTP → 스테이징 |
| 치아보험 TPA/ASO | 청구 · 지급 | X12 **837D** / **835** 또는 합의 추출 | 월 1회 | SFTP, 가능하면 Secure Data Sharing |
| 임직원 앱 | 동의, 문진, 사진 메타, 이용 이벤트 | JSON | 준실시간 | API 이벤트 스트림 → Snowpipe |
| 임상 파트너 | 상담 결과, 연계, 완료 | JSON | 이벤트 | API |

**Secure Data Sharing을 우선 검토해야 합니다.** TPA가 Snowflake를 쓴다면 파일 전송 없이 공유로 받을 수 있고, 사본이 생기지 않아 데이터 권리 협상이 쉬워집니다. 다만 같은 리전이어야 하며 (A2에 종속), 아니면 SFTP로 갑니다. 이건 Snowflake 아키텍트에게 물어볼 항목입니다.

---

## 3. 레이어 구조

```
RAW        원본 그대로. 변형 없음. 감사·재처리용.
  ↓
STAGED     파싱·타입 지정·표준화. 원본 키 유지.
  ↓
CANONICAL  정본 모델. 신원 해석 완료. 이 문서의 4절.
  ↓
MART       파생 지표. 실험군, member-month 집계.
  ↓
EMPLOYER   기업 노출용. 집계 정책 + 행 접근 정책 적용. 9절.
```

각 레이어는 별도 스키마이고 **권한이 다릅니다.** RAW·STAGED·CANONICAL은 데이터 엔지니어링 롤만, EMPLOYER는 기업 사용자 롤만 접근합니다. 기업 사용자는 CANONICAL을 아예 볼 수 없습니다.

---

## 4. 정본 데이터 모델

### 4.1 신원 — 가장 어려운 부분

HRIS의 사람, TPA의 가입자, 앱 사용자는 **서로 다른 식별자 체계**를 씁니다. 이걸 하나로 묶는 것이 이 시스템에서 기술적으로 가장 위험한 지점입니다.

```sql
-- 정본 개인. 대리키만 밖으로 나간다.
CREATE TABLE canonical.party (
  party_sk          NUMBER IDENTITY PRIMARY KEY,
  employer_id       VARCHAR      NOT NULL,
  birth_date        DATE,                      -- 매칭용. 마스킹 대상.
  relationship_code VARCHAR,                   -- 18=본인, 01=배우자, 19=자녀
  created_at        TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- 원천별 식별자. 한 사람이 여러 행을 가진다.
CREATE TABLE canonical.party_xref (
  party_sk        NUMBER    NOT NULL REFERENCES canonical.party,
  source_system   VARCHAR   NOT NULL,          -- HRIS | TPA | APP | CLINICAL
  source_id       VARCHAR   NOT NULL,
  match_method    VARCHAR   NOT NULL,          -- DETERMINISTIC | PROBABILISTIC | MANUAL
  match_score     FLOAT,
  matched_at      TIMESTAMP_NTZ,
  PRIMARY KEY (source_system, source_id)
);
```

**매칭 규칙 (가정 A6 기준):**

1. **결정적 매칭** — `subscriber_id + birth_date + relationship_code` 완전 일치. 대부분 여기서 붙습니다.
2. **보조 결정적** — 위가 실패하면 `subscriber_id + 성씨 + 생년월` (자녀 쌍둥이 등 관계코드 충돌 대비).
3. **미매칭 격리** — 붙지 않은 레코드는 버리지 않고 `canonical.party_match_exception`에 남깁니다. **매칭률은 데이터 품질 지표로 매주 보고합니다.**

확률적 매칭은 **1차에서 쓰지 않습니다.** 잘못 붙으면 A의 청구가 B의 이용으로 집계되고, 그 오류는 집계 화면에서 보이지 않습니다. 매칭률이 낮으면 확률적 매칭을 도입하는 게 아니라 **TPA·HRIS에 공통 키를 요구**하는 것이 옳은 대응입니다.

### 4.2 가입 자격과 member-month

```sql
-- 자격 기간. 834에서 온다.
CREATE TABLE canonical.eligibility_span (
  party_sk        NUMBER   NOT NULL,
  employer_id     VARCHAR  NOT NULL,
  plan_id         VARCHAR  NOT NULL,
  effective_date  DATE     NOT NULL,
  term_date       DATE,                        -- NULL = 현재 유효
  coverage_tier   VARCHAR,                     -- EE | EE+SP | EE+CH | FAMILY
  source_file_id  VARCHAR  NOT NULL
);

-- 비용 분모의 grain. span을 월 단위로 전개.
CREATE TABLE canonical.member_month (
  party_sk        NUMBER   NOT NULL,
  employer_id     VARCHAR  NOT NULL,
  plan_id         VARCHAR  NOT NULL,
  month_start     DATE     NOT NULL,
  covered_days    NUMBER   NOT NULL,           -- 부분 월 처리
  is_subscriber   BOOLEAN  NOT NULL,
  PRIMARY KEY (party_sk, month_start)
);
```

**부분 월을 어떻게 셀지 먼저 정해야 합니다.** 15일에 입사한 사람이 그 달에 1.0 member-month인지 0.5인지에 따라 PMPM이 달라집니다. 권장은 `covered_days`를 저장하고 집계 시점에 규칙을 적용하는 것입니다 — 규칙이 바뀌어도 재적재가 필요 없습니다.

`Eligible employees` = 해당 월 member_month 중 `is_subscriber = TRUE`인 사람 수.
`Covered members` = 해당 월 member_month 전체 (본인 + 가족).

### 4.3 청구

```sql
CREATE TABLE canonical.claim_line (
  claim_line_sk    NUMBER IDENTITY PRIMARY KEY,
  party_sk         NUMBER   NOT NULL,
  employer_id      VARCHAR  NOT NULL,
  claim_id         VARCHAR  NOT NULL,
  line_number      NUMBER   NOT NULL,
  service_date     DATE     NOT NULL,          -- 발생일 (incurred)
  paid_date        DATE,                       -- 지급일
  received_date    DATE     NOT NULL,          -- 우리가 받은 날 — 지연 계산용
  cdt_code         VARCHAR  NOT NULL,          -- D1110 등
  provider_npi     VARCHAR,
  allowed_amount   NUMBER(12,2),
  plan_paid_amount NUMBER(12,2),
  member_oop_amount NUMBER(12,2),
  claim_status     VARCHAR  NOT NULL,          -- PAID | DENIED | REVERSED | ADJUSTED
  adjusts_claim_line_sk NUMBER,                -- 재작성 체인
  snapshot_id      VARCHAR  NOT NULL           -- 6절
);
```

`allowed` / `plan_paid` / `member_oop`를 **분리해서 저장**합니다. 제안서가 "세 값이 서로 다르게 움직일 수 있다"고 말하는 근거가 여기입니다. 하나로 합치면 그 주장을 데이터로 보일 수 없습니다.

`claim_status`와 `adjusts_claim_line_sk`가 재작성을 다룹니다. **취소·조정된 청구를 덮어쓰지 않고 새 행으로 쌓습니다.** 덮어쓰면 과거에 보고한 숫자를 재현할 수 없습니다.

### 4.4 앱 이벤트 · 동의 · 신호

```sql
CREATE TABLE canonical.app_event (
  event_sk     NUMBER IDENTITY PRIMARY KEY,
  party_sk     NUMBER      NOT NULL,
  employer_id  VARCHAR     NOT NULL,
  event_type   VARCHAR     NOT NULL,  -- REGISTERED | QUESTIONNAIRE | PHOTO_CAPTURE
                                      -- | SUPPORT_REQUESTED | APPOINTMENT_BOOKED
  occurred_at  TIMESTAMP_NTZ NOT NULL,
  payload      VARIANT
);

-- 동의는 이벤트와 분리한다. 철회 이력이 남아야 한다.
CREATE TABLE canonical.consent (
  party_sk         NUMBER      NOT NULL,   -- 동의의 대상이 되는 사람
  consent_type     VARCHAR     NOT NULL,   -- DATA_PROCESSING | PHOTO | CLAIMS_LINKAGE
  consent_version  VARCHAR     NOT NULL,
  granted_at       TIMESTAMP_NTZ NOT NULL,
  revoked_at       TIMESTAMP_NTZ,
  -- 17절. 누가 어떤 자격으로 동의했는지가 대상과 다를 수 있다.
  granted_by_credential_sk NUMBER NOT NULL,
  capacity         VARCHAR     NOT NULL,   -- SELF | GUARDIAN
  PRIMARY KEY (party_sk, consent_type, granted_at)
);

-- 사진 파생 신호. 원본 사진은 여기 없다. 7절.
CREATE TABLE canonical.oral_signal (
  party_sk        NUMBER      NOT NULL,
  captured_at     TIMESTAMP_NTZ NOT NULL,
  image_uri       VARCHAR     NOT NULL,   -- 외부 저장소 포인터
  model_version   VARCHAR     NOT NULL,   -- 재현성. 필수.
  quality_passed  BOOLEAN     NOT NULL,
  signal_band     VARCHAR,                -- LOW | MODERATE | PRIORITY
  captured_by_credential_sk NUMBER NOT NULL,  -- 17.4. 대상과 다를 수 있다.
  PRIMARY KEY (party_sk, captured_at, model_version)
);
```

`consent`를 이벤트에서 분리한 이유: **철회가 소급 적용되어야** 하기 때문입니다. 동의를 철회한 사람의 데이터를 이후 집계에서 제외하려면 동의 상태를 시점별로 조회할 수 있어야 하고, 이벤트 스트림에 섞어두면 그게 어렵습니다.

`model_version`은 선택이 아닙니다. 모델이 바뀌면 같은 사진이 다른 밴드로 분류될 수 있고, 버전 없이는 과거 분포를 재현할 수 없습니다.

`signal_band`는 **저장하되 기업 화면에는 개인 단위로 절대 노출하지 않습니다.** 9절 정책이 이를 강제합니다.

### 4.5 실험군 배정

```sql
CREATE TABLE canonical.experiment_assignment (
  party_sk        NUMBER   NOT NULL,
  experiment_id   VARCHAR  NOT NULL,
  arm             VARCHAR  NOT NULL,   -- INTERVENTION | CONTROL
  assigned_at     TIMESTAMP_NTZ NOT NULL,
  assignment_seed VARCHAR  NOT NULL,   -- 재현용
  PRIMARY KEY (party_sk, experiment_id)
);
```

> **경고.** 이 테이블은 제안서 QA 체크리스트에 **"ICLO 판단 필요 — 미해결"**로 올라가 있는 항목입니다. 임직원을 복지 프로그램의 개입군·대조군으로 배정하는 것은 동의 근거, 배정 공정성, 복지 차별 금지, 프로토콜 승인이 정리되기 전에는 구현하면 안 됩니다. 스키마는 여기 두되 **파일럿 1차에서는 만들지 않는 것을 권합니다.**

---

## 5. member-month 전개

```sql
-- span → 월. 부분 월은 일수로 남긴다.
INSERT INTO canonical.member_month
SELECT
    s.party_sk,
    s.employer_id,
    s.plan_id,
    DATE_TRUNC('MONTH', d.month_date)                       AS month_start,
    DATEDIFF('day',
        GREATEST(s.effective_date, DATE_TRUNC('MONTH', d.month_date)),
        LEAST(COALESCE(s.term_date, '9999-12-31'::DATE),
              LAST_DAY(d.month_date))) + 1                  AS covered_days,
    s.relationship_code = '18'                              AS is_subscriber
FROM canonical.eligibility_span s
JOIN util.month_spine d
  ON d.month_date BETWEEN DATE_TRUNC('MONTH', s.effective_date)
                      AND COALESCE(s.term_date, CURRENT_DATE());
```

`util.month_spine`은 월 달력 테이블입니다. 이렇게 하면 자격이 중간에 끊긴 사람도 정확히 처리됩니다.

---

## 6. 청구 지연 — 화면의 `60-day lag`가 나오는 곳

치과 청구는 진료 후 몇 달 뒤에 들어오고, 들어온 뒤에도 조정됩니다. 이걸 처리하지 않으면 **지난달에 보고한 숫자가 이번 달에 달라지는데 왜 달라졌는지 설명할 수 없습니다.**

### 스냅샷 방식

매 적재마다 `snapshot_id`를 부여하고, 보고는 항상 **"어느 스냅샷 기준"**인지 명시합니다.

```sql
CREATE VIEW mart.claims_as_of AS
SELECT *
FROM canonical.claim_line
WHERE snapshot_id <= :as_of_snapshot
  AND claim_status <> 'REVERSED';
```

### 완결성 추정

화면의 `completeness 98.4%`는 이렇게 나옵니다:

```sql
-- 서비스월별로 "지금까지 도착한 비율"을 과거 지연 곡선과 비교
WITH lag_curve AS (          -- 과거 실적에서 학습한 누적 도착 곡선
  SELECT months_since_service, AVG(cum_pct) AS expected_pct
  FROM mart.claim_lag_history GROUP BY 1
)
SELECT
    c.service_month,
    SUM(c.allowed_amount)                                   AS received,
    SUM(c.allowed_amount) / NULLIF(l.expected_pct, 0)       AS projected_ultimate,
    l.expected_pct                                          AS completeness
FROM mart.claims_by_service_month c
JOIN lag_curve l
  ON l.months_since_service = DATEDIFF('month', c.service_month, CURRENT_DATE())
GROUP BY c.service_month, l.expected_pct;
```

> **가정 A7 종속.** 지연 곡선은 최소 12~18개월의 실적이 있어야 신뢰할 수 있습니다. **파일럿 1년차에는 이 곡선이 없습니다.** 1차에는 TPA가 제공하는 업계 표준 곡선을 쓰거나, 완결성을 추정하지 말고 **"청구 수신 기준일"만 표시**하는 것이 정직합니다. 화면의 98.4%는 합성 데모 값이며, 실데이터에서 이 숫자를 내려면 곡선의 출처를 밝혀야 합니다.

---

## 7. PHI 경계 — 원본 사진

```
[임직원 웹앱]  ← 14절. 아직 미구축 (가정 A9)
   │ 원본 구강 이미지 업로드
   ↓
[ICLO 운영 미국 리전 객체 저장소]  ← 암호화, 접근 로그, 보존 정책
   │  · 이미지 바이너리는 이 경계를 나가지 않는다
   │  ↓ 이미지 참조만 전달
   │ [ICLO Core AI · 추론 API]  ← 같은 신뢰 경계 안. 14절.
   │  ↑ 파생 신호 + 모델 버전 반환
   ↓ URI + 메타데이터 + 승인된 파생 신호만
[Snowflake canonical.oral_signal]
```

Snowflake에 들어가는 것은 `image_uri`, `captured_at`, `model_version`, `quality_passed`, `signal_band` 뿐입니다. **바이너리는 들어가지 않습니다.**

`image_uri`는 그 자체로는 이미지를 열 수 없어야 합니다 — 서명된 임시 URL을 별도 권한으로 발급받아야 접근되는 구조여야 하고, Snowflake 권한만으로는 사진에 도달할 수 없어야 합니다.

**아직 정해지지 않은 것:** 저장소 벤더·계정 소유자, 암호화 키 관리 주체, 보존·삭제 규칙, 감사 경로, 사고 대응 경계. 제안서에서도 이 부분은 "Controlled U.S. object storage / PHI vault" 한 줄뿐이며, Snowflake 보안 담당자가 가장 먼저 물어볼 지점입니다.

---

## 8. Snowflake 물리 설계

```
계정: 미국 리전 · Business Critical · BAA 체결 (가정 A5)

DATABASE  ICLO_EVIDENCE
  ├── RAW_HRIS / RAW_TPA / RAW_APP / RAW_CLINICAL
  ├── STAGED
  ├── CANONICAL
  ├── MART
  └── EMPLOYER            ← 기업 노출 전용. 뷰만 존재.

WAREHOUSE
  WH_INGEST     XS  자동정지 60초   월배치 적재
  WH_TRANSFORM  S   자동정지 60초   정본 변환
  WH_BI         XS  자동정지 60초   대시보드 조회
```

**웨어하우스 사이징 (가정 A1 = 1만 명 기준):** 월 member_month 약 22,000행, 연간 청구 라인 약 25,000~40,000행. 데이터량 자체는 작습니다. 이 규모에서 비용은 데이터 크기가 아니라 **웨어하우스 가동 시간**에서 나오므로 자동정지를 짧게 두는 것이 핵심입니다. 제안서의 2.5K/10K/25K 사이징 세션에서 Snowflake SE와 확정할 항목입니다.

멀티 테넌시는 **행 단위 분리**로 갑니다. 기업마다 계정이나 DB를 나누지 않고 `employer_id`로 분리하며, 9절 행 접근 정책이 이를 강제합니다. 기업 수가 늘어도 운영이 선형으로 증가하지 않습니다.

---

## 9. 거버넌스 — 여기가 제안의 핵심

제안서와 부스 덱이 "기업 화면에는 집계만, n ≥ 20"이라고 말합니다. **현재 데모는 이걸 JavaScript로 구현하고 있습니다. 실제 시스템에서는 DB가 강제해야 합니다.** 애플리케이션 통제는 애플리케이션을 우회하면 무너지지만, 정책 통제는 어떤 쿼리 경로로 와도 적용됩니다.

### 9.1 롤

| 롤 | 접근 | 용도 |
|---|---|---|
| `R_ENGINEER` | RAW · STAGED · CANONICAL | 파이프라인 개발·운영 |
| `R_ANALYST` | CANONICAL(마스킹) · MART | 내부 분석 |
| `R_EMPLOYER_<id>` | EMPLOYER 뷰만 | 기업 사용자 |
| `R_CLINICAL` | oral_signal · 임상 이벤트 | 임상 검토 |
| `R_AUDIT` | ACCESS_HISTORY | 감사 |

기업 사용자는 CANONICAL에 **어떤 권한도 없습니다.** EMPLOYER 스키마의 뷰만 봅니다.

### 9.2 행 접근 정책 — 기업 간 격리

```sql
CREATE ROW ACCESS POLICY gov.employer_isolation
  AS (employer_id VARCHAR) RETURNS BOOLEAN ->
     CURRENT_ROLE() IN ('R_ENGINEER','R_ANALYST')
     OR employer_id = SYSTEM$GET_TAG('gov.employer_id', CURRENT_ROLE(), 'ROLE');

ALTER TABLE canonical.member_month
  ADD ROW ACCESS POLICY gov.employer_isolation ON (employer_id);
ALTER TABLE canonical.claim_line
  ADD ROW ACCESS POLICY gov.employer_isolation ON (employer_id);
```

### 9.3 집계 정책 — n ≥ 20을 DB가 강제

Snowflake **aggregation policy**가 최소 그룹 크기를 쿼리 엔진 차원에서 강제합니다. 이게 이 설계에서 가장 중요한 한 조각입니다.

```sql
CREATE AGGREGATION POLICY gov.min_cell_20
  AS () RETURNS AGGREGATION_CONSTRAINT ->
     CASE
       WHEN CURRENT_ROLE() IN ('R_ENGINEER','R_ANALYST')
         THEN NO_AGGREGATION_CONSTRAINT()
       ELSE AGGREGATION_CONSTRAINT(MIN_GROUP_SIZE => 20)
     END;

ALTER TABLE canonical.member_month  SET AGGREGATION POLICY gov.min_cell_20;
ALTER TABLE canonical.claim_line    SET AGGREGATION POLICY gov.min_cell_20;
ALTER TABLE canonical.oral_signal   SET AGGREGATION POLICY gov.min_cell_20;
ALTER TABLE canonical.app_event     SET AGGREGATION POLICY gov.min_cell_20;
```

효과: `R_EMPLOYER_*` 롤이 어떤 쿼리를 던지든 **20명 미만 그룹은 결과로 나오지 않습니다.** 개별 행 조회도 막힙니다 (1행 = 그룹 크기 1).

**알아둘 동작:** 정책 위반 시 오류가 아니라 작은 그룹들을 **remainder group**으로 합치고 GROUP BY 컬럼을 NULL로 반환합니다. 화면은 이 NULL 그룹을 "억제됨"으로 표시해야 하며, 지금 데모처럼 자체 판정하지 않습니다.

**제약** (Snowflake 문서 기준): 외부 테이블 불가, `GROUP BY ROLLUP/CUBE/GROUPING SETS` 불가, 윈도우 함수 불가, 대부분의 집합 연산 불가, **Enterprise 이상** 필요. 우리는 Business Critical이므로 에디션 조건은 충족합니다. 다만 윈도우 함수 금지는 추세 계산에 영향을 주므로, **추세는 MART에서 미리 계산해 EMPLOYER 뷰에 노출**하는 방식으로 설계해야 합니다.

### 9.4 마스킹

```sql
CREATE MASKING POLICY gov.mask_birth_date AS (val DATE) RETURNS DATE ->
  CASE WHEN CURRENT_ROLE() IN ('R_ENGINEER') THEN val ELSE NULL END;

ALTER TABLE canonical.party
  MODIFY COLUMN birth_date SET MASKING POLICY gov.mask_birth_date;
```

`party_sk`는 대리키라 그 자체로는 개인을 식별하지 않지만, **기업 사용자에게는 어차피 노출되지 않습니다** (9.1). 분석가에게도 필요 없으면 EMPLOYER·MART 뷰에서 제외합니다.

### 9.5 접근 이력

`SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY`를 그대로 두면 되고, `R_AUDIT`에 조회 권한을 줍니다. **누가 어떤 테이블의 어떤 컬럼을 언제 조회했는지**가 남습니다 — BAA 하에서 요구되는 감사 능력입니다.

---

## 10. 기업 화면용 집계 뷰

```sql
CREATE VIEW employer.v_overview AS
SELECT
    mm.employer_id,
    mm.month_start,
    dept.department,
    COUNT(DISTINCT CASE WHEN mm.is_subscriber THEN mm.party_sk END) AS eligible_employees,
    COUNT(DISTINCT mm.party_sk)                                     AS covered_members,
    SUM(mm.covered_days) / 30.4                                     AS member_months,
    SUM(c.allowed_amount) / NULLIF(SUM(mm.covered_days) / 30.4, 0)  AS dental_pmpm
FROM canonical.member_month mm
LEFT JOIN mart.party_department dept ON dept.party_sk = mm.party_sk
LEFT JOIN mart.claims_as_of      c
       ON c.party_sk = mm.party_sk
      AND DATE_TRUNC('MONTH', c.service_date) = mm.month_start
GROUP BY 1, 2, 3;
```

이 뷰를 `R_EMPLOYER_*`가 조회하면 집계 정책이 자동 적용되어 20명 미만 부서·구간은 remainder group으로 빠집니다. **뷰에 억제 로직을 쓰지 않았는데도 억제됩니다** — 그게 정책 통제의 요점입니다.

---

## 11. 데이터 품질

매 적재마다 자동 검증하고, 실패하면 다음 레이어로 승격하지 않습니다.

| 검사 | 기준 | 실패 시 |
|---|---|---|
| 신원 매칭률 | 결정적 매칭 ≥ 95% | 경고. 주간 보고. |
| 자격 공백 | 같은 사람의 span 중첩·역전 없음 | 적재 중단 |
| 청구–자격 정합 | 청구 발생일에 자격 유효 | 예외 격리 |
| 금액 정합 | `allowed ≥ plan_paid + member_oop` | 예외 격리 |
| 중복 | `claim_id + line_number` 유일 | 적재 중단 |
| member-month 연속성 | 전월 대비 ±10% 이내 | 경고 |

**신원 매칭률이 가장 중요한 지표입니다.** 이게 떨어지면 "청구로 확인된 완료"가 조용히 과소집계되고, 집계 화면에서는 보이지 않습니다. 주간 서면 현황에 넣어야 합니다.

---

## 12. 구축 순서 — 90일 계획에 매핑

제안서의 90일 계획에 대응시킨 것입니다. **데이터 권리 매트릭스가 Day 30 선행 조건**이며, 그 전에는 실데이터 적재를 시작하지 않습니다.

| 시점 | 작업 | 산출물 |
|---|---|---|
| Step 0 | Business Critical·BAA·리전 확정 (A5) | 서면 확인 |
| ~Day 30 | 데이터 권리 매트릭스, 원천 필드 매핑, 공통 키 확인 (A6) | 매핑 문서, 매칭 가능성 판정 |
| ~Day 30 | 계정·롤·스키마·정책 골격, 합성 데이터로 정책 검증 | 정책 DDL, 검증 결과 |
| Day 31–60 | RAW·STAGED 적재, 신원 해석, 정본 모델 | 매칭률 리포트 |
| Day 31–60 | 보안 기준 구조 공동 작성 및 승인 | 승인된 보안 문서 |
| Day 61–90 | MART·EMPLOYER 뷰, 대시보드 연결, 품질 검사 자동화 | 실데이터 대시보드 |
| Day 61–90 | 접근 이력·감사 확인 | 감사 리포트 |

**정책을 마지막에 붙이지 않습니다.** 합성 데이터로 Day 30까지 정책을 먼저 검증하고, 실데이터는 정책이 서 있는 위에 올립니다. 순서를 바꾸면 PHI가 통제 없는 상태로 존재하는 구간이 생깁니다.

---

## 13. 미결 — 법무·계약 판단이 필요한 항목

기술로 풀 수 없는 것들입니다. 제안서 QA 체크리스트의 미해결 항목과 대응합니다.

1. **HIPAA 역할 규정.** ICLO·기업·기업 건강플랜·TPA·Snowflake 각각이 covered entity인지 business associate인지 subcontractor인지. BAA 체인이 이 판정 위에 세워집니다. **미정 상태로 PHI를 적재하면 안 됩니다.**
2. **데이터 권리.** 원천별·필드별·목적별로 무엇을 받아 무엇에 쓸 수 있는지. 기업–TPA 계약의 데이터 권리 조항이 실질적 제약입니다.
3. **동의 근거.** 청구 연결(claims linkage)에 별도 동의가 필요한지, 철회 시 소급 삭제 범위.
4. **n ≥ 20이 충분한가.** 20은 관행적 값이지 법적 기준이 아닙니다. 차분 공격(differencing) 방어까지 고려하면 쿼리 이력 기반 통제가 추가로 필요할 수 있습니다.
5. **실험군 배정** (4.5). 동의·공정성·복지 차별 금지·프로토콜 승인.
6. **보존과 삭제.** 원본 이미지, 파생 신호, 청구 각각의 보존 기간과 삭제 요청 처리.
7. **기업 수신자.** 대시보드를 받는 주체가 사용자인지 플랜 스폰서인지 플랜 관리자인지, 그리고 인사 목적 전용(轉用) 금지를 어떻게 계약으로 막을지.

---

## 14. 임직원 웹앱과 Core AI 연동 (계획)

> **가정 A9.** 이 절은 **아직 만들지 않은 것**에 대한 설계입니다. 웹앱도 Core AI 호출 경로도 현재 존재하지 않으며, 대시보드 데모는 합성 데이터로만 돕니다. 외부 자료에서 이 구조를 현재형으로 설명하면 안 됩니다.

### 14.1 구성 요소

| 구성 | 역할 | 이 문서와의 관계 |
|---|---|---|
| 임직원 웹앱 | 동의, 문진, 사진 촬영, 치과 탐색, 지원 요청 | `app_event` · `consent`의 원천 |
| **ICLO Core AI** | 구강 이미지 추론. **API로 호출** | `oral_signal`의 원천 |
| 근거 레이어 백엔드 | 이 문서 1~13절 | 세 원천을 정본 모델로 |

Core AI를 앱에 내장하지 않고 **API 뒤에 두는 것이 PHI 경계에 유리합니다.** 이미지가 클라이언트를 떠나 통제된 저장소로만 가고, 추론은 그 경계 안에서 일어나며, 밖으로 나가는 것은 파생 신호뿐입니다. 7절 다이어그램이 이 구조입니다.

### 14.2 호출 계약

```
POST /v1/oral-signal
  Authorization: <service credential>
  {
    "image_ref":     "s3://iclo-phi-us/…",   // 바이너리 아님. 참조만.
    "captured_at":   "2026-08-08T04:12:00Z",
    "consent_ref":   "…",                    // 동의 없으면 거부
    "request_id":    "…"                     // 멱등키
  }

200
  {
    "model_version":  "core-ai-2026.07.3",   // 필수. 재현성.
    "quality_passed": true,
    "signal_band":    "MODERATE",            // LOW | MODERATE | PRIORITY
    "inference_id":   "…"
  }
```

설계상 지켜야 할 것:

- **원본 이미지를 요청 본문에 담지 않습니다.** 참조만 보냅니다. 로그·APM·에러 리포트에 이미지가 실려 나가는 사고를 구조적으로 막습니다.
- **`model_version`은 응답 필수 필드입니다.** 4.4절에서 이미 저장 대상으로 잡아뒀습니다. 없으면 과거 신호 분포를 재현할 수 없습니다.
- **`consent_ref` 없이는 추론하지 않습니다.** 동의 확인을 앱이 아니라 API에서 강제해야 앱 우회 시에도 유지됩니다.
- **응답에 질병명·확률을 담지 않습니다.** 밴드만 반환합니다. 제안서가 "원시 질병 확률을 노출하지 않는다"고 말하는 근거가 API 계약에 있어야 합니다.
- **멱등키**로 재시도 시 중복 신호가 쌓이지 않게 합니다.

### 14.3 백엔드 적재

```
웹앱 이벤트  → API 이벤트 스트림 → Snowpipe → RAW_APP     → canonical.app_event
Core AI 응답 → 추론 결과 큐      → Snowpipe → RAW_APP     → canonical.oral_signal
```

Core AI 응답을 앱이 직접 Snowflake에 쓰지 않고 **큐를 거칩니다.** 추론은 비동기이고 실패·재시도가 있으므로, 앱 세션 수명과 적재를 분리해야 유실이 생기지 않습니다.

### 14.4 대시보드가 실데이터로 바뀔 때

현재 대시보드는 브라우저 안에서 합성 숫자를 만듭니다. 실데이터로 전환하면 **표시 계층은 그대로 두고 데이터 공급만 바뀝니다** — 화면은 이미 하나의 상수 블록에서 모든 숫자를 파생시키도록 정리돼 있으므로(`test_single_source.py`가 이를 강제), 그 블록을 `employer.v_overview` 조회 결과로 교체하는 것이 전환의 골자입니다.

**단, 억제는 함께 옮겨야 합니다.** 지금 데모는 n≥20을 JavaScript로 판정하는데, 실데이터에서는 9.3절 집계 정책이 이를 대신하고 화면은 remainder group(NULL)을 "억제됨"으로 표시만 합니다. 두 곳에 판정 로직을 두면 언젠가 어긋납니다.

### 14.5 이 절이 미치는 범위

- **13절 법무 항목이 늘어납니다.** Core AI가 별도 서비스라면 그 자체가 BAA 체인에 들어가는 주체인지 판정이 필요합니다. 자체 운영이면 내부 통제로, 외부 위탁이면 subcontractor BAA로 갑니다.
- **12절 일정에 웹앱 구축이 없습니다.** 90일 계획은 데이터 레이어만 다룹니다. 웹앱과 Core AI 연동은 별도 트랙이며, 두 일정의 의존 관계를 정리해야 합니다 — 앱이 없으면 `app_event`가 비어 있고, 그러면 참여율·퍼널·"청구로 확인된 완료"가 전부 계산되지 않습니다.

## 15. 데모용 합성 데이터 생성

대시보드 데모는 지금 비율 상수로 숫자를 만듭니다. 개인이 없으니 **억제·매칭·지연 같은 것을 진짜로 보여줄 수 없습니다.** 개인 레벨 3년치를 생성해 실제 파이프라인에 태우면, 데모가 화면 흉내가 아니라 시스템의 축소판이 됩니다.

### 15.1 원칙

**실데이터와 같은 파이프라인을 탑니다.** 합성 데이터를 화면에 직접 주입하지 않고 `RAW_*`에 넣어 STAGED → CANONICAL → MART → EMPLOYER를 그대로 통과시킵니다. 그래야 집계 정책·행 접근 정책·매칭 로직이 데모에서도 실제로 작동합니다. 화면만 채우면 9절 통제가 검증되지 않습니다.

### 15.2 모집단과 3년

| 항목 | 값 | 비고 |
|---|---|---|
| 기간 | 36개월 | 청구 지연 곡선(6절)을 학습시키기에 최소 |
| 자격자 | 시나리오별 2,500 / 10,000 / 25,000 | 기존 데모 시나리오 유지 |
| 가족 | 자격자당 0~4명, 평균 1.2명 | DEP_RATIO 2.2와 정합 |
| 입·퇴사 | 연 이직률 12~28% (기업별로 다름) | 자격 span이 중간에 끊기는 경우 발생 |

**자격이 계속 유지되는 사람만 만들면 안 됩니다.** 중도 입사·퇴사·가족 추가·플랜 변경이 있어야 `eligibility_span`이 여러 행으로 쪼개지고, member-month 전개(5절)와 부분 월 처리가 실제로 시험됩니다.

### 15.3 참여 — 여기가 핵심

사람마다 다르게 행동해야 합니다. **전원이 같은 확률로 참여하면 억제도 분포도 의미가 없습니다.**

```
개인별 참여 유형 (자격자에게 배정)
  NEVER          45%   앱 설치 안 함. 이벤트 0건. 청구는 있을 수 있음.
  ONE_SHOT       17%   가입 후 1회 촬영하고 이탈
  SPORADIC       23%   불규칙. 연 1~2회. 간격 편차 큼
  REGULAR        15%   분기~반기 주기. 간격 편차 작음
```

- **NEVER가 45%인 것이 중요합니다.** 이 사람들은 `member_month`에는 있지만 `app_event`가 없습니다. 그래야 `Activated` 분모(자격자)와 분자(앱 사용자)가 실제로 갈라지고, 앞서 고친 "eligible employees는 앱 사용자가 아니다"가 데이터로 증명됩니다.
- **가족도 따로 배정합니다.** 임직원이 REGULAR여도 배우자는 NEVER일 수 있습니다. 가족 참여율이 임직원보다 낮은 것이 현실적입니다.
- **기록 주기는 개인 안에서도 변동합니다.** REGULAR라도 정확히 90일마다가 아니라 평균 90일·표준편차 30일 정도로 흩뜨립니다. 고정 주기면 월별 집계가 부자연스러운 톱니가 됩니다.

### 15.4 청구 생성

앱 참여와 **부분적으로만** 상관되어야 합니다. 참여자가 전부 진료를 받고 미참여자가 아무도 안 받으면 인과가 조작된 데이터가 되고, "청구로 확인된 완료" 로직을 시험할 수 없습니다.

- 기저 예방진료 이용률을 전원에게 부여 (참여 여부와 무관)
- 참여자에게 소폭 상향 — 다만 **효과 크기를 크게 잡지 않습니다.** 데모 데이터에서 큰 효과가 보이면 그 화면을 근거처럼 쓰게 됩니다
- CDT 코드 분포: D1000계열(예방) 다수, D2000(수복)·D4000(치주) 소수
- `service_date`와 `received_date`를 분리하고 **지연을 분포로** 부여 (중앙값 45일, 롱테일 180일까지). 6절 지연 곡선이 여기서 나옵니다
- 일부는 `REVERSED`/`ADJUSTED`로 재작성 체인을 만듭니다

### 15.5 매칭 난이도 주입

생성 시 **일부러 붙지 않는 레코드를 섞습니다.** 3~5%를 생년월일 오타, 관계코드 불일치, subscriber ID 포맷 차이로 만들면 4.1절 매칭 로직과 예외 격리가 실제로 시험됩니다. 전부 깨끗하면 매칭률 100%가 나오고, 실데이터에서 처음으로 문제를 만나게 됩니다.

### 15.6 재현성

시드를 고정하고 생성 파라미터를 파일로 남깁니다. 같은 시드는 같은 데이터를 만들어야 하며, 그래야 "지난주 데모와 숫자가 다른데요"가 생기지 않습니다.

---

## 16. 기업 온보딩

기술 작업보다 **계약·데이터 권리·커뮤니케이션이 임계 경로**입니다. 순서를 틀리면 데이터를 받고도 쓸 수 없습니다.

### 16.1 단계

| 단계 | 하는 일 | 완료 조건 | 막히면 |
|---|---|---|---|
| **0. 적격 판정** | self-funded인지, 치아보험 TPA가 누구인지, 청구 데이터 권리가 기업에 있는지 | 3개 모두 Yes | 여기서 탈락시킵니다. 뒤에서 발견하면 비용이 큽니다 |
| **1. 계약·데이터 권리** | 기업–ICLO 계약, 기업–TPA 데이터 권리 조항 확인, BAA 체인 | 원천별·목적별 권리 매트릭스 서면 | 대부분 여기서 지연됩니다 |
| **2. 기술 연결** | 834 SFTP, TPA 청구 경로, 테스트 파일 왕복 | 테스트 파일 파싱 성공, 매칭률 확인 | A6 실패 시 공통 키 협상으로 되돌아감 |
| **3. 기준선 적재** | 과거 12~24개월 자격·청구 적재 | 매칭률·완결성 리포트 | — |
| **4. 임직원 안내·동의** | 사내 공지, 앱 안내, 동의 수집 | 동의 흐름 가동 | 노조·근로자대표 협의가 필요한 기업이 있음 |
| **5. 화면 개통** | 기업 롤 발급, EMPLOYER 뷰 연결 | 기업이 자기 데이터만 보는 것 확인 | — |

**0단계를 가볍게 넘기지 마십시오.** 제안서 slide 15(계정 근거 표)가 바로 이 판정을 위한 체크리스트입니다. `Self-funded dental admin?` `Claim-line data in Snowflake?` `Customer introduction ready?` 세 칸이 0단계의 산출물입니다.

### 16.2 순서에서 지켜야 할 것

- **동의(4단계)보다 데이터 권리(1단계)가 먼저입니다.** 임직원 동의는 ICLO가 데이터를 처리할 근거이고, 데이터 권리는 기업이 TPA로부터 데이터를 받아 ICLO에 줄 수 있는 근거입니다. 별개이고 둘 다 필요합니다.
- **기준선 적재(3단계)를 앱 출시(4단계)보다 먼저** 합니다. 과거 청구가 있어야 개통 첫날부터 PMPM·예방진료 이용률의 기저값을 보여줄 수 있습니다. 앱부터 열면 몇 달간 빈 화면입니다.
- **기업 롤 발급(5단계)은 마지막입니다.** 9.2절 행 접근 정책이 붙기 전에 계정을 주면 다른 기업 데이터가 보입니다.

### 16.3 첫 기업에서 반드시 측정할 것

파일럿 1곳은 "되는지"가 아니라 **"두 번째 기업에서 얼마나 빨라지는지"**를 알아내는 것이 목적입니다.

| 지표 | 왜 |
|---|---|
| 0→2단계 소요일 | 계약·권리가 임계 경로인지 확인 |
| 834 첫 파일까지 소요일 | HRIS 팀 부담 실측 |
| 결정적 매칭률 | A6 검증. 90% 미만이면 모델을 바꿔야 함 |
| 재작업 횟수 | 매핑 문서로 줄일 수 있는 부분 |
| 동의율 | 사내 안내 방식의 효과 |

이 다섯 개가 두 번째 기업의 견적이 됩니다. 제안서의 Day 30 "계정 검증 행 1건"이 이걸 위한 것입니다.

### 16.4 기업이 물어볼 것 — 미리 준비

1. *"우리 임직원 개인 정보를 우리가 볼 수 있나요?"* → **아니오.** 집계만, n≥20. 9절 정책이 강제하며 우회 경로가 없습니다.
2. *"인사 평가에 쓸 수 있나요?"* → **아니오.** 계약으로 금지해야 하는 항목입니다 (13절 7번).
3. *"우리 TPA가 협조 안 하면요?"* → 0단계에서 걸러집니다. 데이터 권리가 기업에 있어도 TPA 운영 협조는 별개입니다.
4. *"직원이 동의를 철회하면요?"* → 이후 집계에서 제외됩니다. 4.4절 `consent`가 시점별 조회를 지원합니다.
5. *"비용이 오히려 늘면요?"* → 1년차는 오를 수 있습니다. 제안서가 첫해 절감을 약속하지 않는 이유입니다.

---

## 17. 임직원·가족 계정과 기기 — 온보딩의 실제 문제

16.4단계를 "링크 보내고 동의받기"로 적어뒀지만, 그 한 줄 뒤에 이 시스템에서 가장 틀리기 쉬운 설계가 있습니다.

### 17.1 잘못된 전제 세 가지

| 전제 | 왜 틀렸나 |
|---|---|
| 사람 1명 = 계정 1개 | 미성년 자녀는 계정을 못 만듭니다 |
| 계정 1개 = 기기 1대 | 부부가 한 폰을 씁니다. 자녀 둘이 한 태블릿을 씁니다 |
| 임직원이 가족 동의를 대신할 수 있다 | **성인 가족은 스스로 동의해야 합니다.** 배우자·성인 자녀에 대해 임직원이 대신 동의할 권한은 없습니다 |

세 번째가 법적으로 가장 위험합니다. 편의상 "가족 전체 동의" 체크박스를 임직원 화면에 두면, 배우자 데이터 처리의 동의 근거가 무효가 될 수 있습니다.

### 17.2 사람 · 계정 · 기기를 분리

**기기는 신원이 아닙니다.** 세 층을 따로 둡니다.

```sql
-- 로그인 주체. 사람과 1:1이 아니다.
CREATE TABLE canonical.credential (
  credential_sk  NUMBER IDENTITY PRIMARY KEY,
  employer_id    VARCHAR NOT NULL,
  contact_hash   VARCHAR NOT NULL,       -- 전화/이메일의 해시. 원문 저장 안 함.
  created_at     TIMESTAMP_NTZ NOT NULL,
  disabled_at    TIMESTAMP_NTZ
);

-- 계정이 어떤 사람을 대신해 행동할 수 있는가. N:M.
CREATE TABLE canonical.profile_access (
  credential_sk  NUMBER  NOT NULL,
  party_sk       NUMBER  NOT NULL,
  access_role    VARCHAR NOT NULL,       -- SELF | GUARDIAN | (성인 가족은 SELF만)
  granted_at     TIMESTAMP_NTZ NOT NULL,
  revoked_at     TIMESTAMP_NTZ,
  PRIMARY KEY (credential_sk, party_sk, granted_at)
);
```

- 한 계정이 여러 사람을 볼 수 있고 (부모가 자녀 둘)
- 한 사람이 여러 계정에서 접근될 수 있습니다 (배우자가 자기 폰과 공용 태블릿 양쪽)
- **성인은 `GUARDIAN`으로 붙일 수 없습니다.** 성인 가족의 `profile_access`는 그 사람 본인의 credential에 `SELF`로만 생깁니다

### 17.3 초대 흐름 — 834에는 가족 연락처가 없다

이게 설계를 규정합니다. 834는 가족의 이름·생년월일·관계는 주지만 **연락처는 대개 없습니다.** 그래서 가족에게 직접 링크를 보낼 수 없고, 임직원을 거쳐야 합니다.

```
1. 기업이 임직원에게 안내 (사내 채널)
2. 임직원이 링크로 진입 → 본인 동의 (capacity=SELF)
3. 화면에 834 기준 가족 목록이 뜬다 — 이름과 관계만, 임직원이 이미 아는 정보
4. 임직원이 가족별로 분기
     미성년 자녀  → 임직원이 그 자리에서 대리 동의 (capacity=GUARDIAN)
     성인 가족    → 임직원이 그 가족의 연락처를 입력하거나 초대 링크를 전달
                     → 가족이 자기 credential로 진입 → 본인 동의 (capacity=SELF)
5. 동의 안 한 사람은 그대로 둔다 — member_month에는 남고 app_event만 없다
```

4단계에서 **성인 가족용 초대를 임직원이 대신 눌러 통과시킬 수 없어야** 합니다. 링크를 전달받은 사람이 별도 인증(문자 OTP 등)을 거쳐야 `capacity=SELF` 동의가 성립합니다.

### 17.4 한 폰을 여럿이 쓰는 경우 — 사진 귀속

말씀하신 조합이 전부 정상 경로입니다.

| 상황 | 처리 |
|---|---|
| 임직원 + 가족 전원이 한 폰 | credential 1개. 미성년은 `GUARDIAN` 프로필, 성인 가족은 **같은 기기에서 자기 credential로 로그인**해 `SELF` 동의 |
| 임직원과 가족이 각자 폰 | credential 각각. `profile_access`가 사람별로 붙음 |
| 임직원+A는 폰1, B·C·D는 폰2 | credential 2개, `profile_access` 4행. **프로필은 기기에 매이지 않습니다** |

**진짜 위험은 사진 오귀속입니다.** 폰을 공유하는데 프로필 전환이 느슨하면 B의 사진이 C로 들어가고, 그 오류는 집계 화면에서 절대 보이지 않습니다. `oral_signal`이 오염되면 청구 연결까지 함께 틀어집니다.

방어:

1. **촬영 직전 프로필을 명시적으로 고르게 합니다.** 세션에 걸쳐 기억하지 않습니다.
2. **직전 프로필을 자동 선택하지 않습니다.** 공유 기기에서 가장 흔한 사고 경로입니다.
3. 촬영 화면에 **대상자 이름을 크게** 띄웁니다.
4. 비활동 시 프로필을 해제합니다.
5. `oral_signal.captured_by_credential_sk`를 **대상과 별도로 기록**합니다. 한 credential이 3분 안에 5명분을 촬영하는 패턴을 탐지할 수 있어야 하고, 이건 정상일 수도(가족 검진일) 사고일 수도 있어 자동 차단이 아니라 **품질 지표로 관찰**합니다.

### 17.5 놓치기 쉬운 경계

- **자녀가 18세가 되는 순간.** 부양 자격은 26세까지 가는데 동의 자격은 18세에 넘어옵니다. 생일이 지나면 부모의 `GUARDIAN` 접근을 끊고 본인 동의를 새로 받아야 합니다. **자격 기간 안에서 조용히 발생하므로 배치로 감지**해야 합니다.
- **연락처 재사용.** 자녀 계정에 부모 전화번호를 쓰면 `contact_hash`가 충돌합니다. credential은 연락처가 아니라 대리키로 식별하고, 같은 연락처에 복수 credential을 허용해야 합니다.
- **임직원 퇴사.** 자격이 끊기면 가족 자격도 끊깁니다. 그런데 배우자의 동의와 데이터는 배우자의 것입니다 — 계정 비활성화와 데이터 삭제는 별개 결정이며 13절 보존 정책에 걸립니다.
- **이혼·분리.** 전 배우자의 `profile_access`를 임직원 계정에서 제거해야 하는데, 834에서 관계 종료가 늦게 반영될 수 있습니다.
- **동의 철회가 가족 단위가 아닙니다.** 임직원이 철회해도 성인 배우자의 동의는 유효합니다. 반대도 마찬가지입니다.
- **계정이 아예 없는 사람.** 15.3절 NEVER 45%가 여기 해당합니다. 이 사람들도 `member_month`와 청구는 있으므로 **계정 없음이 정상 상태**여야 하고, 온보딩 완료율을 100%로 잡는 설계를 하면 안 됩니다.

### 17.6 법무 확인 필요

13절에 추가됩니다.

1. 성인 가족 동의를 임직원이 대신할 수 없다는 전제가 맞는지, 관할별로 다른지
2. 미성년 대리 동의의 연령 기준 (18세? 13세 이상은 본인 동의 병행?)
3. 18세 전환 시 재동의 의무와 유예 기간
4. 공유 기기에서 성인 가족 인증을 어느 수준까지 요구해야 하는지 (OTP로 충분한지)
5. 임직원 퇴사 후 가족 데이터의 보존·삭제 주체

---

## 부록. 현재 데모와의 차이

| 항목 | 현재 데모 | 실제 시스템 |
|---|---|---|
| 데이터 | 합성, 브라우저 안에서 생성 | 4개 원천 실데이터 |
| n ≥ 20 억제 | JavaScript 표시 단계 | Snowflake 집계 정책 (쿼리 엔진) |
| 기업 격리 | 없음 (시나리오 전환) | 행 접근 정책 |
| 청구 지연 | 고정 문구 `60-day lag` | 스냅샷 + 지연 곡선 |
| 완결성 98.4% | 고정값 | 추정치. 곡선 확보 전에는 표시하지 않기 권장 (6절) |
| 신원 | 없음 | 결정적 매칭 + 예외 격리 |
| 숫자 공급 | 브라우저 내 상수 블록 | `employer.v_overview` 조회 (14.4) |
| 추론 | 없음 | Core AI 추론 API (14절, 미구축) |
| 합성 데이터 | 비율 상수 | 개인 레벨 3년치, 파이프라인 통과 (15절) |
| Trend vs control | 탭 제거 | 실험군 배정 승인 후 복귀 |
| 계정·기기 | 없음 | credential · profile_access 분리 (17절) |

데모는 **기업이 무엇을 보게 되는지**를 보여주는 화면이고, 이 문서는 **그 화면 뒤에 무엇이 있어야 하는지**입니다. 두 개를 같은 것으로 설명하지 않아야 합니다.
